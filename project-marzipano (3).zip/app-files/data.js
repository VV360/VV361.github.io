var APP_DATA = {
  "scenes": [
    {
      "id": "0-r0010497",
      "name": "R0010497",
      "levels": [
        {
          "tileSize": 256,
          "size": 256,
          "fallbackOnly": true
        },
        {
          "tileSize": 512,
          "size": 512
        },
        {
          "tileSize": 512,
          "size": 1024
        },
        {
          "tileSize": 512,
          "size": 2048
        }
      ],
      "faceSize": 1680,
      "initialViewParameters": {
        "yaw": -1.9334493199441027,
        "pitch": 0.29484135749257945,
        "fov": 1.3715802068843215
      },
      "linkHotspots": [],
      "infoHotspots": [
        {
          "yaw": 1.1839669785081686,
          "pitch": 0.33978656603835766,
          "title": "Title",
          "text": "Text"
        }
      ]
    }
  ],
  "name": "Project Marzipano",
  "settings": {
    "mouseViewMode": "qtvr",
    "autorotateEnabled": true,
    "fullscreenButton": true,
    "viewControlButtons": true
  }
};
